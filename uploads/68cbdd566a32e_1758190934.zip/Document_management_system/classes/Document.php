<?php
class Document {
    private $db;
    public function __construct($db) {
        $this->db = $db;
    }
    // Add your document methods here
}
