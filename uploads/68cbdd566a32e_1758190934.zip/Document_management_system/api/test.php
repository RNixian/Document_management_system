<?php
echo json_encode(['success' => true, 'message' => 'API is working']);
?>
